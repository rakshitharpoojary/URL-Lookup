# Introduction

The Stylight-Assessment Service provides the functionality for URL Lookup for the website.

# Information
I have used 'url-mapping.json' file as URL mapping table in this application and Redis server for caching.

# Getting Started

Run below commands to setup Redis Server for caching
(Make sure Docker is installed in your machine)
1. `docker pull redis`
2. `docker run --rm -p 4025:6379 -d --name redis-1 redis redis-server`

Once Redis server is up and running in your local machine, please run the project.

## Task 1

I have implemented a Service to Lookup URLs in both ways.

## Task 2
I have exposed two endpoints:

1. Receives a list of parameterized URLs and returns a map of provided parameterized URLs as keys with corresponding pretty URLs as values
endpoint: /get-pretty-urls
HTTP method: Post
Request body: accepts array of strings

ex:
```
    [
        "/products",
        "/products?gender=female",
        "/products?gender=female&tag=123&tag=1234&tag=5678",
        "/xyzhj"
    ]
```
Response : Returns status code 200 with key-value pairs of parameterized-urls and pretty-urls

ex:
```
    {
        "/products?gender=female": "/Women/",
        "/xyzhj": "/xyzhj",
        "/products?gender=female&tag=123&tag=1234&tag=5678": "/Women/Shoes/",
        "/products": "/Fashion/"
    }
```

2. Receives a list of pretty URLs, and returns a map of provided pretty URLs as keys and corresponding parameterized URLs as values
endpoint: /get-parameterized-urls
HTTP method: Post
Request body: accepts array of strings

ex:
```
    [
        "/Women/",
        "/Fashion/",
        "/Women/Shoes/",
        "/kids/"
    ]
```
Response : Returns status code 200 with key-value pairs of pretty-urls and parameterized-urls

ex:
```
    {
        "/Fashion/": "/products",
        "/Women/Shoes/": "/products?gender=female&tag=123&tag=1234",
        "/Women/": "/products?gender=female",
        "/kids/": "/kids/"
    }
```


# Note

Due to the time constraint I coud not write test cases for the methods I have implemented.


