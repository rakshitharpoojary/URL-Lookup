package com.stylight.assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StylightAssessmentApplicationTests {

	 
	@Test
	void contextLoads() throws Exception {
	}

}
