package com.stylight.assessment.controller;

import java.util.ArrayList;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.stylight.assessment.service.IURLLookupService;

@RestController
public class URLLookupController {
	
	
	@Autowired
	private IURLLookupService urlLookupService;
	
	@PostMapping(value = "/get-pretty-urls")
	public @ResponseBody ResponseEntity<Object> getPrettyURLs(@RequestBody ArrayList<String> urls){
		Map<String, String> result = null;
		try {
			result = urlLookupService.getPrettyURLs(urls);
					
		} catch (Exception ex) {
			return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
	@PostMapping(value = "/get-parameterized-urls")
	public @ResponseBody ResponseEntity<Object> getParameterizedURLs(@RequestBody ArrayList<String> urls){
		Map<String, String> result = null;
		try {
			result = urlLookupService.getParameterizedURLs(urls);
					
		} catch (Exception ex) {
			return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
}
