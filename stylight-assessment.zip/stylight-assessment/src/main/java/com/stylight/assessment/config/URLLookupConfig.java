package com.stylight.assessment.config;

public class URLLookupConfig {

}
