package com.stylight.assessment.helper;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.Assert;

public class FileHelper {
	public String getFileContent(String fileNameWithPath) throws Exception {		
		ClassPathResource urlLookupFile = new ClassPathResource(fileNameWithPath);
        Assert.notNull(urlLookupFile, String.format("Not able to identify the file: '%s'", fileNameWithPath));
        InputStream inputStream = null;
        try {
            //Read the inputStream into a json string
            inputStream = urlLookupFile.getInputStream();
            Assert.notNull(inputStream, String.format("Not able to load the data: '%s'", fileNameWithPath));
			var json = IOUtils.toString(inputStream, StandardCharsets.UTF_8.name());
            return json;
        } catch (Exception e) {
            throw e;
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }        
	}
}
