package com.stylight.assessment.service;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public interface IURLLookupService {
	Map<String, String> getPrettyURLs(List<String> parameterizedURLs) throws Exception;
	
	Map<String, String> getParameterizedURLs(List<String> prettyURLs) throws Exception;
}
