package com.stylight.assessment.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stylight.assessment.helper.FileHelper;

import me.xdrop.fuzzywuzzy.FuzzySearch;
import me.xdrop.fuzzywuzzy.model.ExtractedResult;

@Service
class URLLookupService implements IURLLookupService{
	private final Logger logger = LoggerFactory.getLogger(URLLookupService.class);	
	
	@Override
	public Map<String, String> getPrettyURLs(List<String> parameterizedURLs) throws Exception{
		Map<String, String> urlMappings = new HashMap<>();
		parameterizedURLs.forEach(key-> {
			try {
				urlMappings.put(key, getPrettyURLForParameterizedURL(key));
			} catch (Exception e) {				
				logger.info("Error occured while upating URL mappings");
			}
		});
		
		return urlMappings;
	}
	
	@Override
	public Map<String, String> getParameterizedURLs(List<String> prettyURLs) throws Exception{
		Map<String, String> urlMappings = new HashMap<>();
		
			prettyURLs.forEach(value-> {
					String key = null;
					try {
						key = getParameterizedURLForPrettyURL(value);
					} catch (Exception e) {
						logger.info("Error occured while upating URL mappings");
					}
					urlMappings.put(value, key);				
			});

		
		return urlMappings;
	}
	
	@Cacheable(value = "urls", key="#parameterizedURL", unless="#result == null")
	private String getPrettyURLForParameterizedURL(String parameterizedURL) throws Exception {
		try {
			Map<String, String> urlMappings = loadURLLookupTable();
			Set<String> values = urlMappings.keySet();
			String matchedURL = getMatchingValue(parameterizedURL, new ArrayList<String>(values), urlMappings);
			if(matchedURL == null)
				return parameterizedURL;
			return urlMappings.get(matchedURL);
		} catch(Exception e) {
			throw e;
		}		
	}
	
	
	@Cacheable(value = "urls", key="#prettyURL", unless="#result == null")
	private String getParameterizedURLForPrettyURL(String prettyURL) throws Exception{
		try {
			Map<String, String> urlMappings = loadURLLookupTable();
			Collection<String> values = urlMappings.values();
			String matchedURL = getMatchingValue(prettyURL, new ArrayList<String>(values), urlMappings);
			
			if(matchedURL == null)
				return prettyURL;
			
			return urlMappings.entrySet().stream()
	                .filter(entry -> matchedURL.equals(entry.getValue()))
	                .findFirst().map(Map.Entry::getKey)
	                .orElse(null);
		} catch(Exception e) {
			throw e;
		}
		
	}
	
	private Map<String, String> loadURLLookupTable() throws Exception {
		try {
		
	        String fileNameWithPath = "url-mapping.json";
	        Assert.notNull(fileNameWithPath, "There is no default url-mapping json file found.");
	
	        var fileHelper = new FileHelper();
	        String urlMappingsJson = fileHelper.getFileContent(fileNameWithPath);
	        
	        byte[] jsonData = urlMappingsJson.getBytes();
	        
	        Map<String, String> urlMappings = new HashMap<>();
	        
	        ObjectMapper mapper = new ObjectMapper();
	        urlMappings = mapper.readValue(jsonData, new TypeReference<HashMap<String, String>>() {});
	        return urlMappings;    	
		} catch(Exception e) {
			throw e;
		}
	}
	
	private String getMatchingValue(String key, List<String> urls, Map<String, String> urlMappings) {
		List<ExtractedResult> match = FuzzySearch.extractSorted(key, urls);
		var matchedURLs = match.stream().filter(x -> x.getScore() >= 70).toList();
		
		if(matchedURLs.isEmpty())
			return null;
		
		return matchedURLs.stream().max(Comparator.comparing(s -> s.getScore())).get().getString();
	}

}
